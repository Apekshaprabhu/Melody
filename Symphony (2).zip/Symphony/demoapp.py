from kivy.app import App
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.core.audio import SoundLoader
from kivy.uix.togglebutton import ToggleButton

class Float_layout_Demo(FloatLayout):
	def __init__(self,**kwargs):
		super().__init__(**kwargs)
	
		self.lab=Label(text='[b]Choose Your Mood [/b]',font_size= '20sp',markup=True,pos_hint={'x':.02 , 'y':.4})
		
		self.add_widget(self.lab)
		
		self.bttn1=Button(
			text="Sad",size_hint=(0.2,0.2),pos_hint={"x":0.20,"y":0.6}
		)
		def btn_pressed(self):
        		sound = SoundLoader.load('sad.mp3')
        		sound.play()
		self.bttn1.bind(on_press=btn_pressed)
		self.add_widget(self.bttn1)
		

		self.bttn2=Button(
			text="Happy",size_hint=(0.2,0.2),pos_hint={"x":0.45,"y":0.6}
		)
		def btn1_pressed(self):
        		sound = SoundLoader.load('happy.mp3')
        		sound.play()
		self.bttn2.bind(on_press=btn1_pressed)
		self.add_widget(self.bttn2)
		self.bttn3=Button(
			text="Angry",size_hint=(0.2,0.2),pos_hint={"x":0.7,"y":0.6}
		)
		def btn2_pressed(self):
        		sound = SoundLoader.load('\Music\Angry.mp3')
        		sound.play()
		self.bttn3.bind(on_press=btn2_pressed)
		self.add_widget(self.bttn3)
		self.bttn4=Button(
			text="Fear",size_hint=(0.2,0.2),pos_hint={"x":0.3,"y":0.3}
		)
		self.add_widget(self.bttn4)
		self.bttn5=Button(
			text="Surprised",size_hint=(0.2,0.2),pos_hint={"x":0.6,"y":0.3}
		)
		self.add_widget(self.bttn5)
		
		self.lab=Label(text='[u][b]Real Time Mood Detection[/b] [/u]',font_size= '20sp',markup=True,pos_hint={"x":0,"y":-0.3}
		)
		
		self.add_widget(self.lab)

	

class DemoApp(App):
	def build(self):
		
		return Float_layout_Demo()

DemoApp().run()